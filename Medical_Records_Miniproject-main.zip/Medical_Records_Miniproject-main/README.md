# Medical_Records_Miniproject




[medical_record_project](hospital.html)
